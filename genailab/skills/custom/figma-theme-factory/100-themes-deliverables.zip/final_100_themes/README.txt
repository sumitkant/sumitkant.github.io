100 Theme Deliverables

Contents:
- markdown/: 100 individual Markdown theme files named with hyphenated theme names.
- theme-showcase-100-themes.pdf: showcase document with one visual page per theme.
- themes-data.json: structured source data used to generate the Markdown and PDF.

Generated from 100combinations.pdf using the arctic-frost.md format and the provided Google Fonts pairing guidance.
